from src.frontend.app import TaskManagerApp
import tkinter as tk

def main():
    root = tk.Tk()
    app = TaskManagerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

