class Project:
    def __init__(self, project_id, name, description):
        self.project_id = project_id
        self.name = name
        self.description = description

    def __repr__(self):
        return f"Project({self.project_id}, {self.name}, {self.description})"
