from data_structures.stack import Stack
from data_structures.queue import Queue
from data_structures.linked_list import LinkedList
from data_structures.hash_table import HashTable
from db.connection import get_db_connection, create_tables

class TaskManager:
    def __init__(self):
        self.tasks = LinkedList()
        self.undo_stack = Stack()
        self.notification_queue = Queue()
        self.user_table = HashTable()
        create_tables()

    def add_task(self, task_id, task):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO tasks (task_id, title, description, status, user_id) VALUES (?, ?, ?, ?, ?)',
                       (task.task_id, task.title, task.description, task.status, task.user_id))
        conn.commit()
        conn.close()
        self.tasks.append(task)
        self.notification_queue.enqueue(f"Task added: {task.title}")

    def get_task(self, task_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM tasks WHERE task_id = ?', (task_id,))
        task = cursor.fetchone()
        conn.close()
        return task if task else "Task not found"

    def add_user(self, user_id, user):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)',
                       (user.user_id, user.username, user.password, user.role))
        conn.commit()
        conn.close()

    def get_user(self, user_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        user = cursor.fetchone()
        conn.close()
        return user if user else "User not found"

    def get_user_by_username(self, username):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        conn.close()
        return user if user else None

    def get_all_users(self):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users')
        users = cursor.fetchall()
        conn.close()
        return users

    def get_all_tasks(self):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM tasks')
        tasks = cursor.fetchall()
        conn.close()
        return tasks

    def undo_last_action(self):
        last_action = self.undo_stack.pop()
        if last_action:
            print(f"Undoing: {last_action}")

    def notify(self):
        while not self.notification_queue.is_empty():
            print(self.notification_queue.dequeue())
