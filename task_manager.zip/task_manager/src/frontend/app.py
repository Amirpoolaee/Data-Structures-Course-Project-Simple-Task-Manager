import tkinter as tk
from tkinter import messagebox
from src.backend.task_manager import TaskManager
from src.backend.task import Task
from src.backend.user import User

class TaskManagerApp:
    def __init__(self, root):
        self.manager = TaskManager()
        self.root = root
        self.root.title("Task Manager")

        self.create_widgets()

    def create_widgets(self):
        # Login and Signup
        self.auth_frame = tk.Frame(self.root)
        self.auth_frame.pack(pady=10)

        self.auth_label = tk.Label(self.auth_frame, text="Login / Signup")
        self.auth_label.pack()

        self.auth_username_label = tk.Label(self.auth_frame, text="Username")
        self.auth_username_label.pack()
        self.auth_username_entry = tk.Entry(self.auth_frame)
        self.auth_username_entry.pack()

        self.auth_password_label = tk.Label(self.auth_frame, text="Password")
        self.auth_password_label.pack()
        self.auth_password_entry = tk.Entry(self.auth_frame, show="*")
        self.auth_password_entry.pack()

        self.login_button = tk.Button(self.auth_frame, text="Login", command=self.login)
        self.login_button.pack(pady=5)

        self.signup_button = tk.Button(self.auth_frame, text="Signup", command=self.signup)
        self.signup_button.pack(pady=5)

        # User Management
        self.user_frame = tk.Frame(self.root)
        self.user_frame.pack(pady=10)

        self.user_label = tk.Label(self.user_frame, text="User Management")
        self.user_label.pack()

        self.username_label = tk.Label(self.user_frame, text="Username")
        self.username_label.pack()
        self.username_entry = tk.Entry(self.user_frame)
        self.username_entry.pack()

        self.password_label = tk.Label(self.user_frame, text="Password")
        self.password_label.pack()
        self.password_entry = tk.Entry(self.user_frame, show="*")
        self.password_entry.pack()

        self.role_label = tk.Label(self.user_frame, text="Role")
        self.role_label.pack()
        self.role_entry = tk.Entry(self.user_frame)
        self.role_entry.pack()

        self.add_user_button = tk.Button(self.user_frame, text="Add User", command=self.add_user)
        self.add_user_button.pack(pady=5)

        # Task Management
        self.task_frame = tk.Frame(self.root)
        self.task_frame.pack(pady=10)

        self.task_label = tk.Label(self.task_frame, text="Task Management")
        self.task_label.pack()

        self.task_title_label = tk.Label(self.task_frame, text="Title")
        self.task_title_label.pack()
        self.task_title_entry = tk.Entry(self.task_frame)
        self.task_title_entry.pack()

        self.task_desc_label = tk.Label(self.task_frame, text="Description")
        self.task_desc_label.pack()
        self.task_desc_entry = tk.Entry(self.task_frame)
        self.task_desc_entry.pack()

        self.task_status_label = tk.Label(self.task_frame, text="Status")
        self.task_status_label.pack()
        self.task_status_entry = tk.Entry(self.task_frame)
        self.task_status_entry.pack()

        self.task_user_id_label = tk.Label(self.task_frame, text="User ID")
        self.task_user_id_label.pack()
        self.task_user_id_entry = tk.Entry(self.task_frame)
        self.task_user_id_entry.pack()

        self.add_task_button = tk.Button(self.task_frame, text="Add Task", command=self.add_task)
        self.add_task_button.pack(pady=5)

        # Notifications
        self.notify_button = tk.Button(self.root, text="Show Notifications", command=self.show_notifications)
        self.notify_button.pack(pady=5)

    def login(self):
        username = self.auth_username_entry.get()
        password = self.auth_password_entry.get()
        user = self.manager.get_user_by_username(username)
        if user and user['password'] == password:
            messagebox.showinfo("Success", f"Welcome {username}!")
        else:
            messagebox.showerror("Error", "Invalid username or password")

    def signup(self):
        username = self.auth_username_entry.get()
        password = self.auth_password_entry.get()
        if self.manager.get_user_by_username(username):
            messagebox.showerror("Error", "Username already exists")
        else:
            user_id = len(self.manager.get_all_users()) + 1
            user = User(user_id, username, password, "User")
            self.manager.add_user(user_id, user)
            messagebox.showinfo("Success", f"User {username} registered successfully!")

    def add_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        role = self.role_entry.get()
        user_id = len(self.manager.get_all_users()) + 1
        user = User(user_id, username, password, role)
        self.manager.add_user(user_id, user)
        messagebox.showinfo("Success", f"User {username} added successfully!")

    def add_task(self):
        title = self.task_title_entry.get()
        description = self.task_desc_entry.get()
        status = self.task_status_entry.get()
        user_id_str = self.task_user_id_entry.get()

        if not user_id_str.isdigit():
            messagebox.showerror("Error", "User ID must be a valid integer")
            return

        user_id = int(user_id_str)
        task_id = len(self.manager.get_all_tasks()) + 1
        task = Task(task_id, title, description, status, user_id)
        self.manager.add_task(task_id, task)
        messagebox.showinfo("Success", f"Task {title} added successfully!")

    def show_notifications(self):
        notifications = []
        while not self.manager.notification_queue.is_empty():
            notifications.append(self.manager.notification_queue.dequeue())
        messagebox.showinfo("Notifications", "\n".join(notifications))

if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManagerApp(root)
    root.mainloop()